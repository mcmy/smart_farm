<template>
  <router-view/>
</template>

<style lang="stylus">
@import "~toastr";
@import "~layui/dist/css/layui.css"

.toast-top-center
  margin-top 10px;

</style>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

html, body {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
  border: 0;
}
</style>
