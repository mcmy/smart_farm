import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import CloudCommon from "@/common/CloudCommon";
import * as toastr from "toastr";

toastr.options = CloudCommon.ToastUtils.toastDef();

createApp(App)
    .use(store)
    .use(router)
    .mount('#app')
