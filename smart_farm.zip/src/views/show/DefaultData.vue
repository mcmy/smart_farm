<template>
  <b>展示</b>
</template>

<script>
export default {
  name: "DefaultData"
}
</script>

<style scoped>

</style>